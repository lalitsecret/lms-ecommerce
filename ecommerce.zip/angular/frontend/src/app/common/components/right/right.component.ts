import { Component, OnInit,Input ,Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'app-right',
  templateUrl: './right.component.html',
  styleUrls: ['./right.component.css']
})
export class RightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  @Input("a")a
  @Output("setCol")setCol:EventEmitter<any>=new EventEmitter();
  col(x)
  {
  	  	this.setCol.emit(x)
  }
}
