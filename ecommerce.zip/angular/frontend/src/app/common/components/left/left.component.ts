import { Component, OnInit ,Input,Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'app-left',
  templateUrl: './left.component.html',
  styleUrls: ['./left.component.css']
})
export class LeftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  @Output("setTagname")setTagname:EventEmitter<any>=new EventEmitter();
  @Input("a")a
  @Input("tagname")tagname

  setClick(x)
  {
  	this.setTagname.emit(x)
  }
}
