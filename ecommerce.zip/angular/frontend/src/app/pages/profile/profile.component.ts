import { Component, OnInit } from '@angular/core';
import { MyService } from '../../services/my.service';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(public ms:MyService) { }

  ngOnInit(): void {
  }

  cp(pwd)
  {
  	let password=prompt("enter new password",pwd)
  	if(password)
  	{
  		if(password===pwd)
  		{
  			alert("password cannot be your prev password")
  		}
  		else{
  			this.ms._patch("users/"+this.ms._user().id,{password:password})
  			.subscribe((d:any)=>{
	  			alert("changed success")
  			})
  		}
  	}
  	else
  	{
  		alert("cancelled by user")
  	}
  }
}
