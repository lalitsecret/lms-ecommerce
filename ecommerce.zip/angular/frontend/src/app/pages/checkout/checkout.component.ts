import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyService } from '../../services/my.service';
@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
	a:any[]=[]
  constructor(private ms:MyService,private router:Router) { }

  ngOnInit(): void {
  	this.ms._get("cart").subscribe((d:any)=>{
         this.a=d.filter(x=>+x.uid===+this.ms._user().id)
  	})
  }

  submit(val)
  {
	for(let item of this.a)
	{
		this.ms._post("orders",item).subscribe(d=>{
			this.ms._delete("cart/"+item.id).subscribe(data=>{
				console.log("done")
			})
		})
	}	  		
	this.router.navigate(["/orders"])
  }
}
