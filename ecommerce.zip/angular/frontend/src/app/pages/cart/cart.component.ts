import { Component, OnInit } from '@angular/core';
import { MyService } from '../../services/my.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
	a:any[]=[]
    constructor(public ms:MyService) { }

  ngOnInit(): void {
  	this.abc()
  }
    abc()
    {
      if(this.ms.loggedin()){
        this.ms._get("cart")
        .subscribe((d:any)=>{
          this.a=d.filter(x=>+x.uid===+this.ms._user().id)
        })  
      }  
      

    }
    removeFromCart(id)
    {
    	this.ms._delete("cart/"+id).subscribe((d)=>{
    		this.a=this.a.filter(x=>x.id!=id)
    	})

    }
    updateQty(id,qty)
    {
		
		this.ms._patch("cart/"+id,{qty:qty}).subscribe((d)=>{
			this.a=this.a.map(x=>x.id===id?d:x)
		})

    }
    

}
