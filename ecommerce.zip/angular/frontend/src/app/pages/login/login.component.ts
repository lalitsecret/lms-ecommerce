import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyService } from '../../services/my.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  a:any[]=[]
  constructor(private ms:MyService,private router:Router) { }

  ngOnInit(): void {
      this.ms._get("users").subscribe((d:any[])=>this.a=d)
  }

  submit(ob)
  {
    if(this.a.some(x=>x.email===ob.email && x.password===ob.password))
    {
      let user=this.a.find(x=>x.email===ob.email && x.password===ob.password)
      alert("login success")
      localStorage.setItem("user",JSON.stringify(user))
      localStorage.setItem("loggedin","true")
      this.router.navigate(["/"])

    }    
    else
    {
       alert("failed to login") 
      localStorage.removeItem("loggedin")
      localStorage.removeItem("user")
      this.router.navigate(["/signup"])
    }

      	
  }
}
