import { Component, OnInit } from '@angular/core';
import { MyService } from '../../services/my.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  a:any[]=[]
  constructor(private ms:MyService,private router:Router) { }

  ngOnInit(): void {
      this.ms._get("users").subscribe((d:any[])=>this.a=d)
  }

  submit(ob)
  {
    if(this.a.some(x=>x.email===ob.email))
    {
      alert("failed to do signup")
            this.router.navigate(["/login"])
    }  	
    else{
      this.ms._post("users",ob)
      .subscribe((d:any)=>{
        alert("signup succesfull")
              this.router.navigate(["/login"])
      })
    }
  }
}
