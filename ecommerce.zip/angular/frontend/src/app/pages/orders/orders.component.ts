import { Component, OnInit } from '@angular/core';
import { MyService } from '../../services/my.service';
@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
		a:any[]=[]
	    constructor(public ms:MyService) { }

	  ngOnInit(): void {
	  	this.abc()
	  }
	    abc()
	    {
	      if(this.ms.loggedin()){
	        this.ms._get("orders")
	        .subscribe((d:any)=>{
	          this.a=d.filter(x=>+x.uid===+this.ms._user().id)
	        })  
	      }  
	      

	    }
	  
}
