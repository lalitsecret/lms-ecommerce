import { Component, OnInit } from '@angular/core';
import { MyService } from '../../services/my.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  products:any[]	
  tags:any[]	
  cart:any[]  
  tagname:string=""
  search:string=""
  col:string="id"
  order:boolean=true


  constructor(public ms:MyService) { }

  ngOnInit(): void {
    this.abc()

  }
  abc()
  {
  	this.ms._get("products")
  	.subscribe((d:any)=>{
			this.products=d
  	})	

  	this.ms._get("tags")
  	.subscribe((d:any)=>{
      this.tags=d
  	})	

    if(this.ms.loggedin()){
      this.ms._get("cart")
      .subscribe((d:any)=>{
        this.cart=d.filter(x=>+x.uid===+this.ms._user().id)
      })  
    }  
    

  }

  setTagname(x){this.tagname=x}
  
  setCol(x){
    this.order=!this.order
    this.col=x
  }
  addtocart(x)
  {
    if(this.cart.some(x=>+x.pid===+x.id && +x.uid===+this.ms._user().id))
    {
      let single=this.cart.find(x=>+x.pid===+x.id && +x.uid===+this.ms._user().id)
      this.ms.cartUpdate(single.id,single.qty+1).subscribe((d:any)=>{
        alert("cart updated")
      })

    }
    else{
      this.ms.addtocart(x).subscribe(d=>{
        alert("aded to cart")
        this.cart.push(d)
      })

    }

  }
}
