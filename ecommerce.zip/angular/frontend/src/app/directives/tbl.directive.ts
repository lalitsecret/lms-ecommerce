import { Directive } from '@angular/core';

@Directive({
  selector: '[appTbl]'
})
export class TblDirective {

  constructor() { }

}
