import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'TagnamePipe'
})
export class TagnamePipe implements PipeTransform {

  transform(a,str): unknown {
    return a.filter((x:any)=>x.tags.startsWith(str));
  }

}
