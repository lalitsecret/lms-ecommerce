import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'SearchPipe'
})
export class SearchPipe implements PipeTransform {

  transform(a,str): unknown {
    return a.filter((x:any)=>Object.values(x).join("").includes(str));
  }

}
