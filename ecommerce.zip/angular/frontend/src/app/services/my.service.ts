import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MyService {
	url:string="http://localhost:8080"
  constructor(private http:HttpClient) { }

  options(){
  	let token=""
  	if(localStorage.getItem('token'))
  	{
  		token=localStorage.getItem('token')	
  	}
  	let opt={
  		headers:new HttpHeaders({
  			Authorization:`bearer ${token}`
  		})
  	}
  	return opt
  }
  _get(str)
  {
  	return this.http.get(`${this.url}/${str}`,this.options())
  }
  _delete(str)
  {
  	return this.http.delete(`${this.url}/${str}`,this.options())
  }
  _post(str,data)
  {
  	return this.http.post(`${this.url}/${str}`,data,this.options())
  }
  _patch(str,data)
  {
  	return this.http.patch(`${this.url}/${str}`,data,this.options())
  }
  loggedin():boolean
  {
     if(localStorage.getItem("loggedin"))
     {
       return true
     }
     else{
       return false
     }

  }
  _user()
  {
     let ob={
       id:0,
       name:"",
       email:"",
       phone:"",
       password:""
     } 
     if(localStorage.getItem("loggedin"))
     {
       return JSON.parse(localStorage.getItem("user"))
     }
     else{
       return ob
     }
  }
  cartUpdate(id,qty)
  {
    return this._patch("cart/"+id,{qty:qty})
  }
  addtocart(x)
  {
    let ob={
      ...x,
      ...this._user(),
      uid:this._user().id,
      pid:x.id,
      qty:1
    }

    delete ob["id"]
    return this._post("cart",ob)

  }

  logout()
  {
    localStorage.removeItem("user")
    localStorage.removeItem("loggedin")
  }
}
