import { Component, OnInit } from '@angular/core';
import { MyService } from './services/my.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  cart:any[]=[]
  orders:any[]=[]
  user:any={id:0}
  loggedin:boolean=false

  constructor(public ms:MyService){


  }
  ngOnInit()
  {
  	this.loggedin=this.ms.loggedin()
  	this.user=this.ms._user()
    this.ms._get("cart").subscribe((d:any[])=>{
      this.cart=d.filter(x=>x.uid===this.user.id)
    })
    this.ms._get("orders").subscribe((d:any[])=>{
      this.orders=d.filter(x=>x.uid===this.user.id)
    })
    
  }
  logout()
  {
    this.ms.logout()
    alert("logout success")
  }

}
